package com.databox.pawnb;

import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;

public class KiranaModel extends AbstractTableModel {
	String columns[] = { "CUSTOMER_ID", "DATE_OF_DEPOSIT", "CUSTOMER_NAME",
			"FATHER_NAME", "ADDRESS1", "ADDRESS2", "ADDRESS3",
			"RATE_OF_INTEREST", "ITEM_NAME", "ITEM_WEIGHT", "OUT_STANDING_AMT",
			"DATE_OF_PAYMENT", "AMOUNT_PAID_STATUS" };
	ArrayList<ArrayList<String>> model = new ArrayList<ArrayList<String>>();

	public KiranaModel() {
		ArrayList<String> row = new ArrayList<String>();
		row.add("CUSTOMER_ID");
		row.add("DATE_OF_DEPOSIT");
		row.add("CUSTOMER_NAME");
		row.add("FATHER_NAME");
		row.add("ADDRESS1");
		row.add("ADDRESS2");
		row.add("ADDRESS3");
		row.add("RATE_OF_INTEREST");
		row.add("ITEM_NAME");
		row.add("ITEM_WEIGHT");
		row.add("OUT_STANDING_AMT");
		row.add("DATE_OF_PAYMENT");
		row.add("AMOUNT_PAID_STATUS");
		model.add(row);
		row = new ArrayList<String>();
		row.add("CUSTOMER_ID");
		row.add("DATE_OF_DEPOSIT");
		row.add("CUSTOMER_NAME");
		row.add("FATHER_NAME");
		row.add("ADDRESS1");
		row.add("ADDRESS2");
		row.add("ADDRESS3");
		row.add("RATE_OF_INTEREST");
		row.add("ITEM_NAME");
		row.add("ITEM_WEIGHT");
		row.add("OUT_STANDING_AMT");
		row.add("DATE_OF_PAYMENT");
		row.add("AMOUNT_PAID_STATUS");
		model.add(row);
		row = new ArrayList<String>();
		row.add("CUSTOMER_ID");
		row.add("DATE_OF_DEPOSIT");
		row.add("CUSTOMER_NAME");
		row.add("FATHER_NAME");
		row.add("ADDRESS1");
		row.add("ADDRESS2");
		row.add("ADDRESS3");
		row.add("RATE_OF_INTEREST");
		row.add("ITEM_NAME");
		row.add("ITEM_WEIGHT");
		row.add("OUT_STANDING_AMT");
		row.add("DATE_OF_PAYMENT");
		row.add("AMOUNT_PAID_STATUS");
		model.add(row);
		row = new ArrayList<String>();
		row.add("CUSTOMER_ID");
		row.add("DATE_OF_DEPOSIT");
		row.add("CUSTOMER_NAME");
		row.add("FATHER_NAME");
		row.add("ADDRESS1");
		row.add("ADDRESS2");
		row.add("ADDRESS3");
		row.add("RATE_OF_INTEREST");
		row.add("ITEM_NAME");
		row.add("ITEM_WEIGHT");
		row.add("OUT_STANDING_AMT");
		row.add("DATE_OF_PAYMENT");
		row.add("AMOUNT_PAID_STATUS");
		model.add(row);
		row = new ArrayList<String>();
		row.add("CUSTOMER_ID");
		row.add("DATE_OF_DEPOSIT");
		row.add("CUSTOMER_NAME");
		row.add("FATHER_NAME");
		row.add("ADDRESS1");
		row.add("ADDRESS2");
		row.add("ADDRESS3");
		row.add("RATE_OF_INTEREST");
		row.add("ITEM_NAME");
		row.add("ITEM_WEIGHT");
		row.add("OUT_STANDING_AMT");
		row.add("DATE_OF_PAYMENT");
		row.add("AMOUNT_PAID_STATUS");
		model.add(row);
		row = new ArrayList<String>();
		row.add("CUSTOMER_ID");
		row.add("DATE_OF_DEPOSIT");
		row.add("CUSTOMER_NAME");
		row.add("FATHER_NAME");
		row.add("ADDRESS1");
		row.add("ADDRESS2");
		row.add("ADDRESS3");
		row.add("RATE_OF_INTEREST");
		row.add("ITEM_NAME");
		row.add("ITEM_WEIGHT");
		row.add("OUT_STANDING_AMT");
		row.add("DATE_OF_PAYMENT");
		row.add("AMOUNT_PAID_STATUS");
		model.add(row);
		row = new ArrayList<String>();
		row.add("CUSTOMER_ID");
		row.add("DATE_OF_DEPOSIT");
		row.add("CUSTOMER_NAME");
		row.add("FATHER_NAME");
		row.add("ADDRESS1");
		row.add("ADDRESS2");
		row.add("ADDRESS3");
		row.add("RATE_OF_INTEREST");
		row.add("ITEM_NAME");
		row.add("ITEM_WEIGHT");
		row.add("OUT_STANDING_AMT");
		row.add("DATE_OF_PAYMENT");
		row.add("AMOUNT_PAID_STATUS");
		model.add(row);
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return columns.length;
	}

	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return model.size();
	}

	public String getColumnName(int c){
		return columns[c];
	}
	
	@Override
	public Object getValueAt(int row, int column) {
		// TODO Auto-generated method stub
		return (model.get(row)).get(column);
	}

}
