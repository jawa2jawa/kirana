/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.dw.gui.pawn;

import com.dw.model.ItemDetailsTableModel;
import com.dw.data.CustomerData;
import com.dw.data.ItemData;
import com.dw.data.SearchCriteria;
import com.dw.data.access.DataManager;
//import com.dw.editor.ItemTableCellEditor;
import com.dw.listener.CustemerTableKeyListener;
import com.dw.listener.ItemCellEditorListener;
import com.dw.model.CustomerTableModel;
import com.dw.rendere.ItemTableCellRenderer;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.print.Printable;
import java.awt.print.PrinterJob;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.TableColumn;

/**
 *
 * @author samuel
 */
public class PawnTopLevelContainer extends javax.swing.JFrame {

    ItemDetailsTableModel itemModel = new ItemDetailsTableModel();
    CustomerTableModel customerTableModel = new CustomerTableModel();
    Dimension dim = new Dimension(117, 34);///Change the
    CustomerData existingCustomerData = new CustomerData();
    public static final String SPACE = "            ";

    /**
     * Creates new form TopLevelContainer
     */
    public PawnTopLevelContainer() {

        initComponents();
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        this.setVisible(true);

        jTabbedPane1.setEnabledAt(1, false);
        jTabbedPane1.setEnabledAt(2, false);
        jTabbedPane1.setEnabledAt(3, false);
        jTabbedPane1.setEnabledAt(4, false);
        jTabbedPane1.setEnabledAt(5, false);

        jScrollPane3.getViewport().setBackground(new Color(255, 255, 255));

        TableColumn col = jTable1.getColumnModel().getColumn(0);
        //  col.setHeaderRenderer(new com.dw.rendere.MyTableHeaderRenderer());
        jTable1.getTableHeader().setFont(new java.awt.Font("Serif", 0, 18));
        jTable1.setRowHeight(35);
        jTable1.setRowSelectionAllowed(true);
        col = jTable1.getColumnModel().getColumn(1);
        /*ItemTableCellEditor editor = new ItemTableCellEditor();
        editor.addCellEditorListener(new ItemCellEditorListener());*/
        // col.setCellEditor(editor);
        //col.setCellRenderer(new ItemTableCellRenderer());
        jTable2.getTableHeader().setFont(new java.awt.Font("Serif", 0, 18));
        jTable3.getTableHeader().setFont(new java.awt.Font("Serif", 0, 18));

        jTable2.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    jTabbedPane1.setEnabledAt(0, false);
                    jTabbedPane1.setEnabledAt(1, false);
                    jTabbedPane1.setEnabledAt(2, true);
                    jTabbedPane1.setEnabledAt(3, false);
                    jTabbedPane1.setEnabledAt(4, false);
                    jTabbedPane1.setEnabledAt(5, false);
                    /**
                     * TODO for setting all fields of the customer
                     */
                    int row = jTable2.getSelectedRow();
                    ArrayList<String> modelData = customerTableModel.getModel().get(row);
                    customerIDTextField.setText(modelData.get(0));
                    customerName.setText(modelData.get(1));

                    createCustomerButton.setActionCommand("Update Customer");
                    createCustomerButton.setText("Update Cutomer");
                    genarateBillButton.setEnabled(true);

                    jTabbedPane1.getModel().setSelectedIndex(2);
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        customerIDTextField.setSize(dim);
        customerIDTextField.setColumns(8);

        rateOfInterestTextField.setSize(dim);
        rateOfInterestTextField.setColumns(8);

        quantityTextField.setSize(dim);
        quantityTextField.setColumns(8);

        //   itemsList.setSize(dim);
      //  itemsList.setColumns(8);
        //   jTable1.setSelectionModel(null);
        // jTable1.getSelectionModel().addListSelectionListener(new CustomerTableSelectionListener());
        // jTable1.addFocusListener(new CustomerTableFocusListener());
        jTable1.addKeyListener(new CustemerTableKeyListener(jTable1, itemModel));
        setFont(new java.awt.Font("Serif", 0, 18));
        setTitle("PAWN BROKER");
        // setSize(Frame.MAXIMIZED_HORIZ, Frame.MAXIMIZED_VERT);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        loginPannel = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        loginButton = new javax.swing.JButton();
        jPasswordField1 = new javax.swing.JPasswordField();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        customerNameTextField = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        cutomerIDTextField_h = new javax.swing.JTextField();
        searchButton = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jPanel13 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel18 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        customerIDLabel = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        customerIDTextField = new javax.swing.JTextField();
        customerName = new javax.swing.JTextField();
        quantityTextField = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        fatherNameTextField = new javax.swing.JTextField();
        rateOfInterestTextField = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        addressTextArea = new javax.swing.JTextArea();
        jPanel7 = new javax.swing.JPanel();
        itemNameTextField = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        itemsList1 = new javax.swing.JComboBox();
        jLabel24 = new javax.swing.JLabel();
        addItemButton = new javax.swing.JButton();
        itemWeightTextField = new javax.swing.JTextField();
        jPanel14 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel19 = new javax.swing.JPanel();
        createCustomerButton = new javax.swing.JButton();
        genarateBillButton = new javax.swing.JButton();
        deleteItemButton = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        //jPanel4 = new javax.swing.JPanel(); new javax.swing.PrintPanel();
        jPanel4 =  new PrintPanel();
        jLabel14 = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jPanel15 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jPanel16 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTabbedPane1.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N

        jPanel1.setBackground(new java.awt.Color(240, 242, 242));
        jPanel1.setLayout(new java.awt.GridBagLayout());

        jLabel1.setFont(new java.awt.Font("Serif", Font.BOLD, 75)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        //jLabel1.setText("PAWN BROKER LOGIN");
        jLabel1.setText("BALAJI PAWN BROKERS");
        jLabel1.setMaximumSize(new java.awt.Dimension(148, 50));
        jLabel1.setMinimumSize(new java.awt.Dimension(148, 50));
        jLabel1.setForeground(Color.BLUE);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.weighty = 0.3;
        jPanel1.add(jLabel1, gridBagConstraints);

        loginPannel.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        loginPannel.setLayout(new java.awt.GridBagLayout());

        jLabel2.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jLabel2.setText("UserName");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 15);
        loginPannel.add(jLabel2, gridBagConstraints);

        jLabel3.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jLabel3.setText("PassWord");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 0, 15);
        loginPannel.add(jLabel3, gridBagConstraints);

        jTextField1.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jTextField1.setText("Admin");
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        loginPannel.add(jTextField1, gridBagConstraints);

        loginButton.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        loginButton.setText("LOGIN");
        //loginButton.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 0, true));
        loginButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.insets = new java.awt.Insets(25, 0, 0, 0);
        loginPannel.add(loginButton, gridBagConstraints);

        jPasswordField1.setText("jPasswordField1");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        loginPannel.add(jPasswordField1, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.7;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 1000, 0);
        jPanel1.add(loginPannel, gridBagConstraints);

        jTabbedPane1.addTab("Login", jPanel1);

        jPanel2.setLayout(new java.awt.GridBagLayout());

        jLabel4.setFont(new java.awt.Font("Serif", 0, 24)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("HOME");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 150, 0);
        jPanel2.add(jLabel4, gridBagConstraints);

        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search Customer", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Serif", 0, 18))); // NOI18N
        jPanel10.setLayout(new java.awt.GridBagLayout());

        jLabel6.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        //jLabel6.setText("Customer Name:");
        jLabel6.setText("M/s:");
        jPanel12.add(jLabel6);

        customerNameTextField.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        customerNameTextField.setText(SPACE);
        customerNameTextField.setSize(dim);
        customerNameTextField.setColumns(15);
        jPanel12.add(customerNameTextField);

        jLabel5.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        //jLabel5.setText("Customer Id:");
        jLabel5.setText("Bill No:");
        jPanel12.add(jLabel5);

        cutomerIDTextField_h.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        cutomerIDTextField_h.setText(SPACE);
        cutomerIDTextField_h.setSize(dim);
        cutomerIDTextField_h.setColumns(15);
        jPanel12.add(cutomerIDTextField_h);

        searchButton.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        searchButton.setText("Search");
        searchButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchButtonActionPerformed(evt);
            }
        });
        jPanel12.add(searchButton);

        jPanel10.add(jPanel12, new java.awt.GridBagConstraints());

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        jPanel2.add(jPanel10, gridBagConstraints);

        jPanel11.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Create Customer", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Serif", 0, 18))); // NOI18N
        jPanel11.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N

        jButton2.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        //jButton2.setText("Create New Customer"); //
        jButton2.setText("Create New Invoice"); //
        //jButton2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 0, true));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton2);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.SOUTH;
        gridBagConstraints.weightx = 1.0;
        jPanel2.add(jPanel11, gridBagConstraints);

        jPanel13.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search Result", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Serif", 0, 18))); // NOI18N
        jPanel13.setLayout(new java.awt.GridBagLayout());

        jScrollPane2.setPreferredSize(new java.awt.Dimension(252, 202));

        jTable2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Serif", 0, 14))); // NOI18N
        jTable2.setFont(new java.awt.Font("Serif", 0, 14)); // NOI18N
        jTable2.setModel(customerTableModel);
        jScrollPane2.setViewportView(jTable2);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        jPanel13.add(jScrollPane2, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.weightx = 1.0;
        jPanel2.add(jPanel13, gridBagConstraints);

        jPanel18.setLayout(new java.awt.GridBagLayout());

        jButton6.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jButton6.setText("Genarate Bill");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel18.add(jButton6, new java.awt.GridBagConstraints());

        jButton4.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        //jButton4.setText("View Customer");
        jButton4.setText("View Invoice");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel18.add(jButton4, new java.awt.GridBagConstraints());

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 1500, 0);
        jPanel2.add(jPanel18, gridBagConstraints);

        jTabbedPane1.addTab("Home", jPanel2);

        jPanel3.setLayout(new java.awt.GridBagLayout());

        jLabel7.setFont(new java.awt.Font("Serif", 0, 24)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("CREATE CUSTOMER DETAILS");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 50, 0);
        jPanel3.add(jLabel7, gridBagConstraints);

        jPanel9.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel9.setLayout(new java.awt.GridBagLayout());

        jLabel8.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jLabel8.setText("Customer Name:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel9.add(jLabel8, gridBagConstraints);

        jLabel11.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 11;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel9.add(jLabel11, gridBagConstraints);

        jLabel13.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jLabel13.setText("Rate Of Interest:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(15, 0, 0, 0);
        jPanel9.add(jLabel13, gridBagConstraints);

        customerIDLabel.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        customerIDLabel.setText("CustomerID:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel9.add(customerIDLabel, gridBagConstraints);

        jLabel16.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jLabel16.setText("Rate Per Gram");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel9.add(jLabel16, gridBagConstraints);

        customerIDTextField.setEditable(false);
        customerIDTextField.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        customerIDTextField.setText("jTextField4");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 0.3;
        jPanel9.add(customerIDTextField, gridBagConstraints);

        customerName.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        customerName.setText("jTextField4");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 0.3;
        jPanel9.add(customerName, gridBagConstraints);

        quantityTextField.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        quantityTextField.setText("           ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        jPanel9.add(quantityTextField, gridBagConstraints);

        jLabel21.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jLabel21.setText("Father Name:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(15, 0, 0, 0);
        jPanel9.add(jLabel21, gridBagConstraints);

        fatherNameTextField.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        fatherNameTextField.setText("           ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.insets = new java.awt.Insets(15, 0, 0, 0);
        jPanel9.add(fatherNameTextField, gridBagConstraints);

        rateOfInterestTextField.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        rateOfInterestTextField.setText("           ");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.weightx = 0.3;
        gridBagConstraints.insets = new java.awt.Insets(15, 0, 0, 0);
        jPanel9.add(rateOfInterestTextField, gridBagConstraints);

        jScrollPane4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Address", javax.swing.border.TitledBorder.LEADING, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Serif", 0, 18))); // NOI18N

        addressTextArea.setColumns(20);
        addressTextArea.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        addressTextArea.setLineWrap(true);
        addressTextArea.setRows(2);
        addressTextArea.setTabSize(5);
        addressTextArea.setToolTipText("");
        addressTextArea.setPreferredSize(new java.awt.Dimension(220, 110));
        jScrollPane4.setViewportView(addressTextArea);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.gridheight = 7;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        jPanel9.add(jScrollPane4, gridBagConstraints);

        jPanel7.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel7.setLayout(new java.awt.GridBagLayout());

        itemNameTextField.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        itemNameTextField.setText("           ");
        itemNameTextField.setSize(dim);
        itemNameTextField.setColumns(6);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        jPanel7.add(itemNameTextField, gridBagConstraints);

        jLabel17.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jLabel17.setText("Item Name:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel7.add(jLabel17, gridBagConstraints);

        jLabel20.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jLabel20.setText("Metal:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel7.add(jLabel20, gridBagConstraints);

        itemsList1.setFont(new java.awt.Font("Serif", 0, 18));
        itemsList1.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Gold     ", "Copper", "Diamond", "Silver","Others" }));
        itemsList1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                itemsList1MouseClicked(evt);
            }
        });
        itemsList1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                itemsList1ActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 5;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        jPanel7.add(itemsList1, gridBagConstraints);

        jLabel24.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jLabel24.setText("Item Weight:");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 6;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel7.add(jLabel24, gridBagConstraints);

        addItemButton.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        addItemButton.setText("AddItem");
        addItemButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addItemButtonActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 9;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        jPanel7.add(addItemButton, gridBagConstraints);

        itemWeightTextField.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        itemWeightTextField.setText("           ");
        itemWeightTextField.setSize(dim);
        itemWeightTextField.setColumns(4);
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 7;
        gridBagConstraints.gridy = 0;
        jPanel7.add(itemWeightTextField, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 8;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel9.add(jPanel7, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        jPanel3.add(jPanel9, gridBagConstraints);

        jPanel14.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder(""), "Added Items", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Serif", 0, 18))); // NOI18N
        jPanel14.setLayout(new java.awt.GridBagLayout());

        jScrollPane1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jScrollPane1.setPreferredSize(new java.awt.Dimension(252, 202));

        jTable1.setFont(new java.awt.Font("Serif", 0, 14)); // NOI18N
        jTable1.setModel(itemModel);
        jScrollPane1.setViewportView(jTable1);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 0.6;
        jPanel14.add(jScrollPane1, gridBagConstraints);

        createCustomerButton.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        createCustomerButton.setText("Create Customer");
        createCustomerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createCustomerButtonActionPerformed(evt);
            }
        });
        jPanel19.add(createCustomerButton);

        genarateBillButton.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        genarateBillButton.setText("Genarate Invoice");
        genarateBillButton.setEnabled(false);
        genarateBillButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                genarateBillButtonActionPerformed(evt);
            }
        });
        jPanel19.add(genarateBillButton);

        deleteItemButton.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        deleteItemButton.setText("DeleteItem");
        deleteItemButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteItemButtonActionPerformed(evt);
            }
        });
        jPanel19.add(deleteItemButton);

        jButton5.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jButton5.setText("Cancel");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel19.add(jButton5);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.weighty = 0.9;
        jPanel14.add(jPanel19, gridBagConstraints);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 0, 250, 0);
        jPanel3.add(jPanel14, gridBagConstraints);

        jTabbedPane1.addTab("Create", jPanel3);

        jPanel4.setLayout(new java.awt.GridBagLayout());

        jLabel14.setFont(new java.awt.Font("Serif", 0, 24)); // NOI18N
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setText("Recept");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        jPanel4.add(jLabel14, gridBagConstraints);

        jPanel17.setBackground(new java.awt.Color(255, 255, 255));
        jPanel17.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));

        jLabel15.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jLabel15.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel15.setText("The Amount Received:");
        jPanel17.add(jLabel15);

        jTextField2.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jTextField2.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jTextField2.setText("jTextField2");
        jPanel17.add(jTextField2);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        jPanel4.add(jPanel17, gridBagConstraints);

        jPanel15.setBackground(new java.awt.Color(255, 255, 255));
        jPanel15.setBorder(null);
        jPanel15.setLayout(new java.awt.BorderLayout());

        jScrollPane3.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane3.setBorder(null);
        jScrollPane3.setForeground(new java.awt.Color(255, 255, 255));
        jScrollPane3.setPreferredSize(new java.awt.Dimension(252, 202));

        jTable3.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jTable3.setFont(new java.awt.Font("Serif", 0, 14)); // NOI18N
        jTable3.setModel(itemModel);
        jScrollPane3.setViewportView(jTable3);

        jPanel15.add(jScrollPane3, java.awt.BorderLayout.CENTER);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.weightx = 1.0;
        jPanel4.add(jPanel15, gridBagConstraints);

        jPanel16.setLayout(new java.awt.GridBagLayout());

        jButton1.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jButton1.setText("Print");
        jPanel16.add(jButton1, new java.awt.GridBagConstraints());
        jButton1.addActionListener(new ActionListener() {
            
            @Override
            public void actionPerformed(ActionEvent e) {
                
                PrinterJob printJob = PrinterJob.getPrinterJob();
                printJob.setPrintable((Printable) jPanel4);
                if (printJob.printDialog()) {
                    try {
                        printJob.print();
                    } catch (Exception ex) {
                        throw new RuntimeException(ex);
                    }
                }
            }
        });
        

        jButton3.setFont(new java.awt.Font("Serif", 0, 18)); // NOI18N
        jButton3.setText("Home");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel16.add(jButton3, new java.awt.GridBagConstraints());

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints.weighty = 0.1;
        jPanel4.add(jPanel16, gridBagConstraints);

        jTabbedPane1.addTab("Bills", jPanel4);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1443, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2209, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("tab5", jPanel5);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1443, Short.MAX_VALUE)
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2209, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("tab6", jPanel6);

        getContentPane().add(jTabbedPane1, java.awt.BorderLayout.PAGE_START);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void deleteItemButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteItemButtonActionPerformed
        // TODO add your handling code here:
        if (evt.getActionCommand() == "DeleteItem") {
            ArrayList<ArrayList<String>> auxModel = new ArrayList<ArrayList<String>>();
            int rows[] = jTable1.getSelectedRows();
            int len = rows.length;
            ArrayList<String> aux = null;
            for (int i = 0; i < len; i++) {
                aux = itemModel.getModel().get(rows[i]);
                auxModel.add(aux);

            }
            len = auxModel.size();
            for (int i = 0; i < len; i++) {
                aux = auxModel.get(i);
                itemModel.getModel().remove(aux);
            }
            itemModel.fireTableDataChanged();

            //     genarateBillButton.setEnabled(true);
        }

        if (evt.getActionCommand() == "Generate Bill") {

            /*deleteItemButton.setText("DeleteItem");
             deleteItemButton.setActionCommand("DeleteItem");*/
        }


    }//GEN-LAST:event_deleteItemButtonActionPerformed

    private void createCustomerButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createCustomerButtonActionPerformed
        // TODO add your handling code here:
        // TODO add your handling code here:
    	//Begin: Popoulate CustomerData object.
        CustomerData customerData = new CustomerData();
        
        customerData.setCustomerName(customerName.getText());
        customerData.setFatherName(fatherNameTextField.getText());
        customerData.setRateOfInterest(rateOfInterestTextField.getText());
        //Rate Per Gram: The label "Quantity" has been renamed as Rate Per Gram.
        customerData.setRatePerGram(quantityTextField.getText());
        //customerData.setAddress1(customerIDTextField.getText());
        customerData.setAddress1(addressTextArea.getText());
        
        //customerData.setPrincipalAmt(principalAmountTextField.getText());
        customerData.setOutStandingAmt("0000000");
        //customerData.setDateOfReceipt(new Date());
        //customerData.setDateOfReceipt("No data of Recipet");
        customerData.setAmountPaidStatus("NOT PAID");
        
        ArrayList<ItemData> itemList = new ArrayList<ItemData>();
        //ItemDetailsTableModel  itemDetailsTable =  new ItemDetailsTableModel();
        ItemDetailsTableModel itemDetailsTable = itemModel;
        for (int i = 0; i < itemDetailsTable.getRowCount(); i++) {
            /*for(int j=0; j<itemDetailsTable.getColumnCount(); j++){
             itemDetailsTable.getValueAt(i,j);
             }*/
            //INDEX OF THE COLUMN HAS BEEN HARD CODED SINCE WE NEED TO PROCESS ALL THE COLUMNS OF A ROW IN ONE SHOT.
            ItemData itemData = new ItemData();
            itemData.setItemName((String) itemDetailsTable.getValueAt(i, 1));
            itemData.setMetal((String) itemDetailsTable.getValueAt(i, 2));
            System.out.println("The Metal===========>" + itemData.getMetal());
            itemData.setWeight((String) itemDetailsTable.getValueAt(i, 3));
            itemData.setQuantity((String) itemDetailsTable.getValueAt(i, 4));
            itemData.setItemPa((String) itemDetailsTable.getValueAt(i, 5));// Pa = item specific principal amount
            
            itemList.add(itemData);
        }
        customerData.setItemList(itemList);
    	//End: Populated CustomerData object.
        if (evt.getActionCommand() == "Create Customer") {
        	 
        	try {
				existingCustomerData = (CustomerData)customerData.clone();
			} catch (CloneNotSupportedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            customerIDTextField.setText(DataManager.saveCustomer(customerData) + "");
            createCustomerButton.setActionCommand("Update Cutomer");
            createCustomerButton.setText("Update Cutomer");
            genarateBillButton.setEnabled(true);
            //////////
            existingCustomerData.setCustomerId(customerIDTextField.getText());
            //////////
            
        }
        if (evt.getActionCommand() == "Update Cutomer") {
        	customerData.setCustomerId(customerIDTextField.getText());
            /*  createCustomerButton.setActionCommand("Create Customer");
             createCustomerButton.setText("Create Customer");
             deleteItemButton.setText("DeleteItem");
             deleteItemButton.setActionCommand("DeleteItem");*/
        	DataManager.updateCustomer(customerData);
        }

    }//GEN-LAST:event_createCustomerButtonActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        itemModel.getModel().clear();
        addressTextArea.setText("");
        jTabbedPane1.setEnabledAt(0, false);
        jTabbedPane1.setEnabledAt(1, false);
        jTabbedPane1.setEnabledAt(2, true);
        jTabbedPane1.setEnabledAt(3, false);
        jTabbedPane1.setEnabledAt(4, false);
        jTabbedPane1.setEnabledAt(5, false);

        customerIDTextField.setSize(dim);
        customerIDTextField.setText("");
        customerName.setSize(dim);
        customerName.setText("");

        createCustomerButton.setActionCommand("Create Customer");
        createCustomerButton.setText("Create Customer");
        genarateBillButton.setEnabled(false);

        jTabbedPane1.getModel().setSelectedIndex(2);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void searchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchButtonActionPerformed
        // TODO add your handling code here:
        customerTableModel.getModel().clear();
        SearchCriteria searchCriteria = new SearchCriteria();
        searchCriteria.setCustomerName(customerNameTextField.getText().trim());
        searchCriteria.setCustomerId(cutomerIDTextField_h.getText());
        ArrayList<CustomerData> customers = DataManager.getCustomersList(searchCriteria);
        int len = customers.size();
        
        //for (int i = 0; i < len; i++) {
        if(null != customers && customers.size()>0){
	        for (CustomerData customerData: customers) {        	
	            //customerData = cutomers.get(i);
	            ArrayList<String> aux = new ArrayList<String>();
	            aux.add(customerData.getCustomerId());
	            aux.add(customerData.getCustomerName());
	            aux.add(customerData.getDateOfReceipt());
	            customerTableModel.getModel().add(aux);
	        }
        }
        
        customerTableModel.fireTableDataChanged();
    }//GEN-LAST:event_searchButtonActionPerformed

    private void loginButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginButtonActionPerformed
        // TODO add your handling code here:
        String userName = jTextField1.getText();
        char passwordc[] = jPasswordField1.getPassword();
        String pwdS = new String(passwordc);
        if (userName.equals("Admin") && pwdS.equals("Admin")) {
            jTabbedPane1.setEnabledAt(0, false);
            jTabbedPane1.setEnabledAt(1, true);
            jTabbedPane1.setEnabledAt(2, false);
            jTabbedPane1.setEnabledAt(3, false);
            jTabbedPane1.setEnabledAt(4, false);
            jTabbedPane1.setEnabledAt(5, false);

            jTabbedPane1.getModel().setSelectedIndex(1);

        } else {
            JOptionPane.showMessageDialog(rootPane, "Invalid credentials..");
        }
    }//GEN-LAST:event_loginButtonActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setEnabledAt(0, false);
        jTabbedPane1.setEnabledAt(1, true);
        jTabbedPane1.setEnabledAt(2, false);
        jTabbedPane1.setEnabledAt(3, false);
        jTabbedPane1.setEnabledAt(4, false);
        jTabbedPane1.setEnabledAt(5, false);

        jTabbedPane1.getModel().setSelectedIndex(1);
    }//GEN-LAST:event_jButton5ActionPerformed

    private void genarateBillButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_genarateBillButtonActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setEnabledAt(0, false);
        jTabbedPane1.setEnabledAt(1, false);
        jTabbedPane1.setEnabledAt(2, false);
        jTabbedPane1.setEnabledAt(3, true);
        jTabbedPane1.setEnabledAt(4, false);
        jTabbedPane1.setEnabledAt(5, false);

        jTabbedPane1.getModel().setSelectedIndex(3);
    }//GEN-LAST:event_genarateBillButtonActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setEnabledAt(0, false);
        jTabbedPane1.setEnabledAt(1, true);
        jTabbedPane1.setEnabledAt(2, false);
        jTabbedPane1.setEnabledAt(3, false);
        jTabbedPane1.setEnabledAt(4, false);
        jTabbedPane1.setEnabledAt(5, false);

        jTabbedPane1.getModel().setSelectedIndex(1);
        //Clear The criteria. i.e. set the criteria to default values.
        customerNameTextField.setText(SPACE);
        cutomerIDTextField_h.setText(SPACE);
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setEnabledAt(0, false);
        jTabbedPane1.setEnabledAt(1, false);
        jTabbedPane1.setEnabledAt(2, false);
        jTabbedPane1.setEnabledAt(3, true);
        jTabbedPane1.setEnabledAt(4, false);
        jTabbedPane1.setEnabledAt(5, false);

        jTabbedPane1.getModel().setSelectedIndex(3);

    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setEnabledAt(0, false);
        jTabbedPane1.setEnabledAt(1, false);
        jTabbedPane1.setEnabledAt(2, true);
        jTabbedPane1.setEnabledAt(3, false);
        jTabbedPane1.setEnabledAt(4, false);
        jTabbedPane1.setEnabledAt(5, false);
        /**
         * TODO for setting all fields of the customer
         */

        int row = jTable2.getSelectedRow();
        ArrayList<String> modelData = customerTableModel.getModel().get(row);
        customerIDTextField.setText(modelData.get(0));
        customerName.setText(modelData.get(1));
        System.out.println("$$$$$$$$$$$$ Before DB call======>"+ customerIDTextField);
        CustomerData customer = DataManager.getCustomerDetails(customerIDTextField.getText());
        fatherNameTextField.setText(customer.getFatherName());
        addressTextArea.setText(customer.getAddress1());
        rateOfInterestTextField.setText(customer.getRateOfInterest());
        addressTextArea.setText(customer.getAddress1());
        quantityTextField.setText(customer.getRatePerGram());
        //Load Item Table
        itemModel.getModel().clear();
        ArrayList<ItemData> items = customer.getItemList();
        for (int i = 0; i < items.size(); i++) {
            ArrayList<String> rowTobeDisplayed = loadRowFromItemData(items.get(i), 10.5);
            itemModel.getModel().add(rowTobeDisplayed);
        }
        itemModel.fireTableDataChanged();
        jTable1.setFont(new java.awt.Font("Serif", 0, 14)); // NOI18N
        jTable1.setModel(itemModel);
        jScrollPane1.setViewportView(jTable1);

        java.awt.GridBagConstraints gridBagConstraints1 = new java.awt.GridBagConstraints();
        gridBagConstraints1.gridx = 0;
        gridBagConstraints1.gridy = 0;
        gridBagConstraints1.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints1.anchor = java.awt.GridBagConstraints.NORTH;
        gridBagConstraints1.weightx = 1.0;
        gridBagConstraints1.weighty = 0.6;
        jPanel14.add(jScrollPane1, gridBagConstraints1);
        //End: Load Item Table
        
        createCustomerButton.setActionCommand("Update Cutomer");
        createCustomerButton.setText("Update Cutomer");
        genarateBillButton.setEnabled(true);
        
        jTabbedPane1.getModel().setSelectedIndex(2);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void itemsList1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_itemsList1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_itemsList1MouseClicked

    private void itemsList1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_itemsList1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_itemsList1ActionPerformed

    private void addItemButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addItemButtonActionPerformed
        ArrayList<String> aux = new ArrayList<String>();
        aux.add(itemNameTextField.getText());
        aux.add((String) itemsList1.getSelectedItem());
        aux.add(itemWeightTextField.getText());
        aux.add(quantityTextField.getText());
        try{
        	double am = Double.parseDouble(itemWeightTextField.getText()) * Double.parseDouble(quantityTextField.getText());
        	aux.add(String.valueOf(am));
        } catch(NumberFormatException nfe){
        	System.out.println("The Reason for Error"+ nfe.getMessage());
        	System.out.println("OPEN THE MODEL DIALOG WITH INSTRUCTIONS TO USER");
        	return;
        }
        
        //aux.add(itemWeightTextField.getText());
        itemModel.addRow(aux);
        itemModel.fireTableDataChanged();        // TODO add your handling code here:
    }//GEN-LAST:event_addItemButtonActionPerformed

    private ArrayList<String> loadRowFromItemData(ItemData item, Double ratePerGram) {
        ArrayList<String> row = new ArrayList<String>();
        String weight = item.getWeight();
        row.add(item.getItemName());
        row.add(item.getMetal());
        row.add(weight);
        row.add(String.valueOf(ratePerGram));
        try{
        row.add(String.valueOf((Double.parseDouble(weight) * ratePerGram)));
        }  catch(NumberFormatException nfe){
        	System.out.println("The Reason for Error"+ nfe.getMessage());
        	System.out.println("OPEN THE MODEL DIALOG WITH INSTRUCTIONS TO USER");
        	return row;
        }
        return row;

    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PawnTopLevelContainer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PawnTopLevelContainer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PawnTopLevelContainer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PawnTopLevelContainer.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PawnTopLevelContainer().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addItemButton;
    private javax.swing.JTextArea addressTextArea;
    private javax.swing.JButton createCustomerButton;
    private javax.swing.JLabel customerIDLabel;
    private javax.swing.JTextField customerIDTextField;
    private javax.swing.JTextField customerName;
    private javax.swing.JTextField customerNameTextField;
    private javax.swing.JTextField cutomerIDTextField_h;
    private javax.swing.JButton deleteItemButton;
    private javax.swing.JTextField fatherNameTextField;
    private javax.swing.JButton genarateBillButton;
    private javax.swing.JTextField itemWeightTextField;
    private javax.swing.JTextField itemNameTextField;
    private javax.swing.JComboBox itemsList1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JButton loginButton;
    private javax.swing.JPanel loginPannel;
    private javax.swing.JTextField quantityTextField;
    private javax.swing.JTextField rateOfInterestTextField;
    private javax.swing.JButton searchButton;
    // End of variables declaration//GEN-END:variables
}
