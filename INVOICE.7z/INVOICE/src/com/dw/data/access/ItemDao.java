package com.dw.data.access;

public class ItemDao extends CommonDao{

}
