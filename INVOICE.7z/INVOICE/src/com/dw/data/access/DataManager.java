package com.dw.data.access;

import java.sql.Connection;
import java.util.ArrayList;

import com.dw.data.CustomerData;
import com.dw.data.ItemData;
import com.dw.data.SearchCriteria;

public class DataManager {
	
	
	public static Integer saveCustomer(CustomerData customerData){
		
		System.out.println("Customer Name: "+customerData.getCustomerName());
		System.out.println("Father Name"+customerData.getFatherName());
		System.out.println("Address"+customerData.getAddress1());
		System.out.println("Rate of Interest"+customerData.getRateOfInterest());
		customerData.setPrincipalAmt("0");
		customerData.setOutStandingAmt("0");
		System.out.println("                    ");
		
		for(ItemData itemdata : customerData.getItemList()){
			System.out.println("Item Name: "+itemdata.getItemName());
			System.out.println("Metal"+itemdata.getMetal());
			System.out.println("Weight"+itemdata.getWeight());
			System.out.println("Quantity"+itemdata.getQuantity());
			System.out.println("Item wise Principal Amount"+itemdata.getItemPa());
			System.out.println("                    ");
		}
		
		CustomerDao customerDao = new CustomerDao();
		return customerDao.saveCustomer(customerData);
		//return new Integer(1234567890);
	}
	
	public static boolean updateCustomer(CustomerData customerData){
		///////// DATA CHECK
		System.out.println("Customer ID: "+customerData.getCustomerId());
		System.out.println("Customer Name: "+customerData.getCustomerName());
		System.out.println("Father Name"+customerData.getFatherName());
		System.out.println("Address"+customerData.getAddress1());
		System.out.println("Rate of Interest"+customerData.getRateOfInterest());
		System.out.println("                    ");
		
		for(ItemData itemdata : customerData.getItemList()){
			System.out.println("Item Name: "+itemdata.getItemName());
			System.out.println("Metal"+itemdata.getMetal());
			System.out.println("Weight"+itemdata.getWeight());
			System.out.println("Quantity"+itemdata.getQuantity());
			System.out.println("Item wise Principal Amount"+itemdata.getItemPa());
			System.out.println("                    ");
		}
		/////////
		boolean updated = false;
		CustomerDao customerDao = new CustomerDao();
		return customerDao.updateCustomer(customerData);
		//return true;
		
	}
	
	public static boolean deleteCustomer(Integer cutomerId){
		boolean deleted = false;
		
		return deleted;
	}
	
	public static CustomerData getCustomerDetails(String cutomerId){
		System.out.println("222222$$$$$$$$$$$$ Before DB call 2 ======>"+ cutomerId);
		CustomerDao customerDao = new CustomerDao();
		return customerDao.getCustomerDetails(cutomerId.trim());
		
	}
	
	public static ArrayList<CustomerData> getCustomersList(SearchCriteria searchCriteria){
		
		ArrayList<CustomerData> customerList = new ArrayList<CustomerData>();
		
		CustomerDao customerDao = new CustomerDao();
		customerList = customerDao.searchCustomer(searchCriteria);
		
		//Replace this hard coded values with the values taken from DB
		/*CustomerData cd = new CustomerData();
		cd.setCustomerName("CustomeName001");
		cd.setCustomerId("1234567890");
		cd.setDateOfReceipt("21-04-2015");// + Other values also available in the cd.
		customerList.add(cd);
		
		CustomerData cd1 = new CustomerData();
		cd1.setCustomerName("CustomerName002");
		cd1.setCustomerId("1234567891");
		cd1.setDateOfReceipt("23-04-2015");// + Other values also available in the cd.
		customerList.add(cd1);
		
		CustomerData cd2 = new CustomerData();
		cd2.setCustomerName("CustomerName003");
		cd2.setCustomerId("1234567892");
		cd2.setDateOfReceipt("24-04-2015");// + Other values also available in the cd.
		customerList.add(cd2);*/
		
		return customerList;
		
	}

}
